﻿using System.Security.Cryptography.Pkcs;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Task4TCS
{
    /// <summary>
    
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void RunClick(object sender, RoutedEventArgs e)
        {
            OneYearSum.Text = "";
            TwoYearsSum.Text = "";
            TotalSum.Text = "";
            Sum.Background = new SolidColorBrush(Colors.White);
            double Money;
            if(!double.TryParse(Sum.Text,out Money)||Money <=0)
            {
                Money = 100;
                Sum.Text = Money.ToString();
                Sum.Background = new SolidColorBrush(Colors.Red);

                return;
            }
            double Total=0;



            bool OneYearSelected = OneYear.IsChecked ?? true;
            double Stafka = OneYearSelected ? 6 : 8;
            double OneYearMoney = Money * (1 + Stafka / 100);
            double OneYearResult = OneYearMoney - Money;
            OneYearSum.Text = $"{OneYearResult:0.00}";

            Total += OneYearResult;


            if(!OneYearSelected)
            {
                double TwoYearMoney = Money * Math.Pow(1 + Stafka / 100,2);
                double TwoYearResult = TwoYearMoney - OneYearMoney;
                TwoYearsSum.Text =$"{TwoYearResult:0.00}";
                Total += TwoYearResult;
            }
            TotalSum.Text = $"{Total:0.00}";
            
            
        }

        private void CloseClick(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void AboutClick(object sender, RoutedEventArgs e)
        {
            AboutWindow _aboutWindow = new AboutWindow();
            _aboutWindow.Show();
        }
        
      
    }
}