﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Task4TCS
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
